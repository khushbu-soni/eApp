<!-- JS files -->
  <script src="<?php echo base_url();?>assets/front/js/jquery.min.js">
  </script>
  <script src="<?php echo base_url();?>assets/front/js/kupon.js">
  </script>
  <script src="<?php echo base_url();?>assets/front/js/bootstrap.min.js">
  </script>
  <script src="<?php echo base_url();?>assets/front/js/jquery.animsition.min.js">
  </script>
  <script src="owl.carousel/owl.carousel.js">
  </script>
  <script src="<?php echo base_url();?>assets/front/js/jquery.flexslider-min.js">
  </script>
  <script src="<?php echo base_url();?>assets/front/js/plugins.js">
  </script>