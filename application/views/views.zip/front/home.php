<!DOCTYPE html>
<html lang="en">
  
  
<!-- Mirrored from codenpixel.com/demo/kupon/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 09 Dec 2015 06:56:58 GMT -->
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <meta charset="utf-8">
  <title>
    Bargain Cry
  </title>
  <meta name="generator" content="#" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <link href="<?php echo base_url(); ?>assets/front/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>assets/front/css/themify-icons.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>assets/front/css/font-awesome.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>assets/front/owl.carousel/assets/owl.carousel.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>assets/front/css/animate.min.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>assets/front/css/animsition.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>assets/front/css/plugins.min.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>assets/front/css/style.css" rel="stylesheet">
  
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">

  <!--[if lt IE 9]>
<script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
  <link rel="shortcut icon" href="#">
  <link rel="apple-touch-icon" href="#">
  <link rel="apple-touch-icon" sizes="72x72" href="#">
  <link rel="apple-touch-icon" sizes="114x114" href="#">
  </head>
  
  <body>
    <div class="site-wrapper animsition" data-animsition-in="fade-in" data-animsition-out="fade-out">
      <?php include('common/header.php');?>
      <!-- /.search form -->
      <div class="slider">
        <div class="container">
          <div class="row">
            <div id="grid-slider" class="flexslider">
              <ul class="slides">
                <?php 
                
                  foreach($query as $que)
                  {
                  ?>
                  <li>
                  <?php
                  $deal_id = $que->id;
                  
                      $ques= $this->deal->get_image_by_name($deal_id);

                      foreach($ques as $q)
                      {
                 ?>
                
                  <div class="col-sm-7 col-lg-8 omega">
                     <article class="bg-image entry-lg" data-image-src="<?php echo base_url(); ?>assets/bargain/deals/<?php echo $q->name; ?>">
                      <div class="deal-short-entry bg-green">
                        <p>
                         <!-- Product 1 Information ! -->
                         <?php echo $que->highlights; ?>
                        </p>
                      </div>
                    </article>
                  </div>
                  <?php  } ?>
                  <div class="col-sm-5 col-lg-4 alpha entry-lg">
                    <div class="buyPanel animated fadeIn bg-white Aligner shadow">
                      <div class="content">
                        <div class="deal-content">
                          <h3>
                            <!-- Sirenis Punta Cana Resort Casino -->
                            <?php echo $que->name; ?>
                          </h3>
                          <p>
                            Best Products Of Day!
                          </p>
                        </div>
                        <ul class="deal-price list-unstyled list-inline">
                          <li class="price">
                            <h3>
                              <!-- $471 -->
                              $<?php echo $que->discounted_price ?>
                            </h3>
                          </li>
                          <li class="buy-now">
                            <a href="<?php echo base_url() ?>deals/view_details/<?php echo $que->id?>/<?php echo $que->merchant_id; ?>/<?php echo $que->subcategory_id; ?>" class="btn btn-success btn-raised ripple-effect">
                              VIEW DEAL
                            </a>
                          </li>
                        </ul>
                        <div class="dealAttributes">
                          <div class="valueInfo bg-light shadow">
                            <div class="value">
                              <p class="value">
                                <!-- $1,422 -->
                                $<?php echo $que->actual_price ?>
                              </p>
                              <p class="text">
                                Value
                              </p>
                            </div>
                            <div class="discount">
                              <p class="value">
                                <!-- 59% -->
                                <?php echo $que->discounted_percentage; ?>%
                              </p>
                              <p class="text">
                                Discount
                              </p>
                            </div>
                            <div class="save">
                              <p class="value">
                                <!-- $976 -->
                                $<?php
                                 $dis_price = $que->discounted_price;
                                 $act_price = $que->actual_price;
                                 $saving = $act_price - $dis_price;
                                 echo $saving;
                                 ?>
                              </p>
                              <p class="text">
                                SAVINGS
                              </p>
                            </div>
                          </div>
                          <!-- /.value info -->
                          <div class="timeLeft text-center">
                             
                          </div>
                          
                          <div class="social-sharing text-center" data-permalink="http://labs.carsonshold.com/social-sharing-buttons">
                            <!-- https://developers.facebook.com/docs/plugins/share-button/ -->
                            <a target="_blank" href="http://www.facebook.com/sharer.php?u=http://themeforest.net/user/codenpixel" class="share-facebook">
                              <span class="icon icon-facebook">
                              </span>
                              <span class="share-title">
                                Share
                              </span>
                              <span class="share-count is-loaded">
                                150
                              </span>
                            </a>
                            <!-- https://dev.twitter.com/docs/intents -->
                            <a target="_blank" href="http://twitter.com/share?url=http://themeforest.net/user/codenpixel" class="share-twitter">
                              <span class="icon icon-twitter">
                              </span>
                              <span class="share-title">
                                Tweet
                              </span>
                              <span class="share-count is-loaded">
                                62
                              </span>
                            </a>
                            
                          </div>
                          <!--/.social sharing -->
                        </div>
                      </div>
                    </div>
                  </div>
                  <!-- /#buypanel -->
                </li>
                <?php  }?>


                <!-- <li>
                  <div class="col-sm-7 col-lg-8 omega">
                    <article class="bg-image entry-lg" data-image-src="<?php echo base_url(); ?>assets/front/images/deal-11.jpg">
                      <div class="deal-short-entry bg-green">
                        <p>
                          Product 2 Information !
                        </p>
                      </div>
                    </article>
                  </div>
                  <div class="col-sm-5 col-lg-4 alpha entry-lg">
                    <div class="buyPanel animated fadeInLeft bg-white Aligner shadow">
                      <div class="content">
                        <div class="deal-content">
                          <h3>
                            Sirenis Punta Cana Resort Casino
                          </h3>
                          <p>
                            Best Products Of Day!
                          </p>
                        </div>
                        <ul class="deal-price list-unstyled list-inline">
                          <li class="price">
                            <h3>
                              $471
                            </h3>
                          </li>
                          <li class="buy-now">
                            <a href="details.php" class="btn btn-success btn-raised ripple-effect">
                              BUY NOW
                            </a>
                          </li>
                        </ul>
                        <div class="dealAttributes">
                          <div class="valueInfo bg-light shadow">
                            <div class="value">
                              <p class="value">
                                $1,422
                              </p>
                              <p class="text">
                                Value
                              </p>
                            </div>
                            <div class="discount">
                              <p class="value">
                                59%
                              </p>
                              <p class="text">
                                Discount
                              </p>
                            </div>
                            <div class="save">
                              <p class="value">
                                $976
                              </p>
                              <p class="text">
                                SAVINGS
                              </p>
                            </div>
                          </div> -->
                          <!-- /.value info -->
                        <!-- <div class="timeLeft text-center">
                            
                          
                            
                            
                          </div>
                          
                          <div class="social-sharing text-center" data-permalink="http://labs.carsonshold.com/social-sharing-buttons"> -->
                            <!-- https://developers.facebook.com/docs/plugins/share-button/ -->
                            <!-- <a target="_blank" href="http://www.facebook.com/sharer.php?u=http://themeforest.net/user/codenpixel" class="share-facebook">
                              <span class="icon icon-facebook">
                              </span>
                              <span class="share-title">
                                Share
                              </span>
                              <span class="share-count is-loaded">
                                150
                              </span>
                            </a> -->
                            <!-- https://dev.twitter.com/docs/intents -->
                           <!--  <a target="_blank" href="http://twitter.com/share?url=http://themeforest.net/user/codenpixel" class="share-twitter">
                              <span class="icon icon-twitter">
                              </span>
                              <span class="share-title">
                                Tweet
                              </span>
                              <span class="share-count is-loaded">
                                62
                              </span>
                            </a>
                            
                          </div> -->
                          <!--/.social sharing -->
                       <!--  </div>
                      </div>
                    </div> -->
                    <!-- /#buypanel -->
                 <!--  </div>
                </li>
                <li>
                  <div class="col-sm-7 col-lg-8 omega">
                    <article class="bg-image entry-lg" data-image-src="<?php echo base_url(); ?>assets/front/images/deal-3.jpg">
                      <div class="deal-short-entry bg-blue">
                        <p>
                          Product 3 Information !.
                        </p>
                      </div>
                    </article>
                  </div>
                  <div class="col-sm-5 col-lg-4 alpha entry-lg">
                    <div class="buyPanel animated fadeInLeft bg-white bordered Aligner">
                      <div class="content">
                        <div class="deal-content">
                          <h3>
                            Riviera Maya All-Inclusive Cities 5*
                          </h3>
                          <p>
                             Best Products Of Day!
                          </p>
                        </div>
                        <ul class="deal-price list-unstyled list-inline">
                          <li class="price">
                            <h3>
                              $999
                            </h3>
                          </li>
                          <li class="buy-now">
                            <a href="details.php"  class="btn btn-primary btn-raised ripple-effect">
                              BUY NOW
                            </a>
                          </li>
                        </ul>
                        <div class="dealAttributes">
                          <div class="valueInfo bg-light shadow">
                            <div class="value">
                              <p class="value">
                                $2,475
                              </p>
                              <p class="text">
                                Value
                              </p>
                            </div>
                            <div class="discount">
                              <p class="value">
                                59%
                              </p>
                              <p class="text">
                                Discount
                              </p>
                            </div>
                            <div class="save">
                              <p class="value">
                                $1,476
                              </p>
                              <p class="text">
                                SAVINGS
                              </p>
                            </div>
                          </div> -->
                          <!-- /.value info -->
                      <!--  <div class="timeLeft text-center">
                            
                          
                            
                            
                          </div>
                          
                          <div class="social-sharing text-center" data-permalink="http://labs.carsonshold.com/social-sharing-buttons"> -->
                            <!-- https://developers.facebook.com/docs/plugins/share-button/ -->
                           <!--  <a target="_blank" href="http://www.facebook.com/sharer.php?u=http://themeforest.net/user/codenpixel" class="share-facebook">
                              <span class="icon icon-facebook">
                              </span>
                              <span class="share-title">
                                Share
                              </span>
                              <span class="share-count is-loaded">
                                150
                              </span>
                            </a> -->
                            <!-- https://dev.twitter.com/docs/intents -->
                            <!-- <a target="_blank" href="http://twitter.com/share?url=http://themeforest.net/user/codenpixel" class="share-twitter">
                              <span class="icon icon-twitter">
                              </span>
                              
                              <span class="share-title">
                                
                                Tweet
                              </span>
                              <span class="share-count is-loaded">
                                62
                              </span>
                            </a>
                            
                          </div> -->
                          <!--/.social sharing -->
                        <!-- </div>
                      </div>
                    </div> -->
                    <!-- /#buypanel -->
                  <!-- </div>
                </li> -->
              </ul>
            </div>
          </div>
        </div>
      </div>
      <!-- /slider -->
      
      
      <section id="page" class="container">
        <div class="shadow  mTop-30 frameLR">
          <div class="row">
            <img src="<?php echo base_url(); ?>assets/front/images/banner.jpg" class="img-responsive">
          </div>
          <!--/.row -->
        </div>
        <!--/.frame -->
        <div class="row">
          <div class="col-sm-12">
            <div class="row">
              <div class="col-sm-12 clearfix">
                <div class="hr-link">
                  <hr class="mBtm-50 mTop-30" data-symbol="FEATURED DEALS">
                  <div class="view-all">
                    <a href="details.php">
                      VIEW ALL
                    </a>
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-sm-3">
                <div class="deal-entry  green">
                  
                  <div class="image">
                    <a href="#" target="_blank" title="#">
                      <img src="<?php echo base_url(); ?>assets/front/images/affiliate-12.jpg" alt="#" class="img-responsive">
                    </a>
                    <span class="bought">
                      <i class="ti-tag">
                      </i>
                      19
                    </span>
                  </div>
                  <!-- /.image -->
                  <div class="title">
                    <a href="#" target="_blank" title="ATLETIKA 3 mēnešu abonements">
                      Product 1
                    </a>
                  </div>
                  <div class="entry-content">
                    <div class="prices clearfix">
                      
                      <div class="price">
                        <i class="ti-money">
                        </i>
                        
                        <b>
                          78,00
                        </b>
                      </div>
                      <div class="old-price">
                        <span>
                          <i class="ti-money">
                          </i>
                          171,00
                        </span>
                      </div>
                    </div>
                    
                  </div>
                  <!--/.entry content -->
                  <footer class="info_bar clearfix">
                    <ul class="unstyled list-inline row">

                      <li>
         <!-- AddToAny BEGIN -->
                        <a class="a2a_dd" href="https://www.addtoany.com/share"><img src="<?php echo base_url(); ?>assets/front/images/share.png" width="80" height="30" border="0" alt="Share"/></a>
                        <script async src="https://static.addtoany.com/menu/page.js"></script>
                        <!-- AddToAny END -->
                      </li> 
                    
                      
                     
                      <li class="info_link col-sm-5 col-xs-6 col-md-4 ">
                        <a style="padding:4px 5px;" href="#" class="btn btn-block btn-success btn-raised btn-sm ">
                          View Deal
                        </a>
                      </li>
                    
                    </ul>
                  </footer>
                </div>
              </div>
              <div class="col-sm-3">
                <div class="deal-entry green">
                  
                  <div class="image">
                    <a href="#" target="_blank" title="#">
                      <img src="<?php echo base_url(); ?>assets/front/images/affiliate-13.jpg" alt="#" class="img-responsive">
                    </a>
                    <span class="bought">
                      <i class="ti-tag">
                      </i>
                      79
                    </span>
                  </div>
                  <!-- /.image -->
                  <div class="title">
                    <a href="#" target="_blank" title="ATLETIKA 3 mēnešu abonements">
                      Product 2
                    </a>
                  </div>
                  <div class="entry-content">
                    <div class="prices clearfix">
                      
                      <div class="price">
                        <i class="ti-money">
                        </i>
                        
                        <b>
                          79,00
                        </b>
                      </div>
                      <div class="old-price">
                        <span>
                          <i class="ti-money">
                          </i>
                          171,00
                        </span>
                      </div>
                    </div>
                   
                  </div>
                  <!--/.entry content -->
                  <footer class="info_bar clearfix">
                    <ul class="unstyled list-inline row">
                       <li>
         <!-- AddToAny BEGIN -->
                        <a class="a2a_dd" href="https://www.addtoany.com/share"><img src="<?php echo base_url(); ?>assets/front/images/share.png" width="80" height="30" border="0" alt="Share"/></a>
                        <script async src="https://static.addtoany.com/menu/page.js"></script>
                        <!-- AddToAny END -->
                      </li> 
                      <li class="info_link col-sm-5 col-xs-6 col-lg-4">
                        <a style="padding:4px 5px;" href="details.php" class="btn btn-block btn-success btn-raised btn-sm">
                          View Deal
                        </a>
                      </li>
                    </ul>
                  </footer>
                </div>
              </div>
               <div class="col-sm-3">
                <div class="deal-entry  green">
                  
                  <div class="image">
                    <a href="#" target="_blank" title="#">
                      <img src="<?php echo base_url(); ?>assets/front/images/affiliate-12.jpg" alt="#" class="img-responsive">
                    </a>
                    <span class="bought">
                      <i class="ti-tag">
                      </i>
                      19
                    </span>
                  </div>
                  <!-- /.image -->
                  <div class="title">
                    <a href="#" target="_blank" title="ATLETIKA 3 mēnešu abonements">
                     Product 3
                    </a>
                  </div>
                  <div class="entry-content">
                    <div class="prices clearfix">
                     
                      <div class="price">
                        <i class="ti-money">
                        </i>
                        
                        <b>
                          78,00
                        </b>
                      </div>
                      <div class="old-price">
                        <span>
                          <i class="ti-money">
                          </i>
                          171,00
                        </span>
                      </div>
                    </div>
                    
                  </div>
                  <!--/.entry content -->
                  <footer class="info_bar clearfix">
                    <ul class="unstyled list-inline row">
                      <li>
         <!-- AddToAny BEGIN -->
                        <a class="a2a_dd" href="https://www.addtoany.com/share"><img src="<?php echo base_url(); ?>assets/front/images/share.png" width="80" height="30" border="0" alt="Share"/></a>
                        <script async src="https://static.addtoany.com/menu/page.js"></script>
                        <!-- AddToAny END -->
                      </li> 
                      <li class="info_link col-sm-5 col-xs-6 col-lg-4">
                        <a style="padding:4px 5px;" href="#" class="btn btn-block btn-success btn-raised btn-sm">
                          View Deal
                        </a>
                      </li>
                    </ul>
                  </footer>
                </div>
              </div>
               <div class="col-sm-3">
                <div class="deal-entry  green">
                  
                  <div class="image">
                    <a href="#" target="_blank" title="#">
                      <img src="<?php echo base_url(); ?>assets/front/images/affiliate-12.jpg" alt="#" class="img-responsive">
                    </a>
                    <span class="bought">
                      <i class="ti-tag">
                      </i>
                      19
                    </span>
                  </div>
                  <!-- /.image -->
                  <div class="title">
                    <a href="#" target="_blank" title="ATLETIKA 3 mēnešu abonements">
                      Product 4
                    </a>
                  </div>
                  <div class="entry-content">
                    <div class="prices clearfix">
                      
                      <div class="price">
                        <i class="ti-money">
                        </i>
                        
                        <b>
                          78,00
                        </b>
                      </div>
                      <div class="old-price">
                        <span>
                          <i class="ti-money">
                          </i>
                          171,00
                        </span>
                      </div>
                    </div>
                    
                  </div>
                  <!--/.entry content -->
                  <footer class="info_bar clearfix">
                    <ul class="unstyled list-inline row">
                     <li>
         <!-- AddToAny BEGIN -->
                        <a class="a2a_dd" href="https://www.addtoany.com/share"><img src="<?php echo base_url(); ?>assets/front/images/share.png" width="80" height="30" border="0" alt="Share"/></a>
                        <script async src="https://static.addtoany.com/menu/page.js"></script>
                        <!-- AddToAny END -->
                      </li> 
                      <li class="info_link col-sm-5 col-xs-6 col-lg-4">
                        <a style="padding:4px 5px;" href="#" class="btn btn-block btn-success btn-raised btn-sm">
                          View Deal
                        </a>
                      </li>
                    </ul>
                  </footer>
                </div>
              </div>
              <!--/.col -->
            </div>
            <!--/row -->
            <!--
           <div class="row" data-gutter="15" style="margin:20px 0px;">
                <div class="col-md-4">
                    <div class="banner" style="background-color:#83599A;">
                        <a class="banner-link" href="#"></a>
                        <div class="banner-caption-top-left">
                            <h5 class="banner-title">Backpack Collection</h5>
                            <p class="banner-desc">Don't Be Vague. Ask for Backpack .</p>
                            <p class="banner-shop-now">Shop Now <i class="fa fa-caret-right"></i>
                            </p>
                        </div>
                        <img class="banner-img" src="images/1-i.png" alt="Image Alternative text" title="Image Title" style="bottom: -8px; right: -32px;">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="banner" style="background-color:#EF4D9C;">
                        <a class="banner-link" href="#"></a>
                        <div class="banner-caption-top-right">
                            <h5 class="banner-title">Best 2015 Tablets</h5>
                            <p class="banner-desc">Double the Pleasure, Double the Tablets.</p>
                            <p class="banner-shop-now">Shop Now <i class="fa fa-caret-right"></i>
                            </p>
                        </div>
                        <img class="banner-img" src="images/2-i.png" alt="Image Alternative text" title="Image Title" style="bottom: -22px; left: 0; width: 235px;">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="banner" style="background-color:#FEA92E;">
                        <a class="banner-link" href="#"></a>
                        <div class="banner-caption-bottom-left">
                            <h5 class="banner-title">Top Glasses</h5>
                            <p class="banner-desc">My Goodness, My Glasses!</p>
                            <p class="banner-shop-now">Shop Now <i class="fa fa-caret-right"></i>
                            </p>
                        </div>
                        <img class="banner-img" src="images/3-i.png" alt="Image Alternative text" title="Image Title" style="top: -4px; right: -15px; width: 220px;">
                    </div>
                </div>
            </div>
            <!--/row -->
            <div class="row">
              <div class="col-sm-12 clearfix">
                <hr class="hr-grid-space" data-symbol="POPULAR DEALS">
              </div>
            </div>
            <div class="row">
              <div class="col-sm-3">
                <div class="deal-entry  green">
                 
                  <div class="image">
                    <a href="#" target="_blank" title="#">
                      <img src="<?php echo base_url(); ?>assets/front/images/affiliate-12.jpg" alt="#" class="img-responsive">
                    </a>
                    <span class="bought">
                      <i class="ti-tag">
                      </i>
                      19
                    </span>
                  </div>
                  <!-- /.image -->
                  <div class="title">
                    <a href="#" target="_blank" title="ATLETIKA 3 mēnešu abonements">
                      Product 1
                    </a>
                  </div>
                  <div class="entry-content">
                    <div class="prices clearfix">
                     
                      <div class="price">
                        <i class="ti-money">
                        </i>
                        
                        <b>
                          78,00
                        </b>
                      </div>
                      <div class="old-price">
                        <span>
                          <i class="ti-money">
                          </i>
                          171,00
                        </span>
                      </div>
                    </div>
                   
                  </div>
                  <!--/.entry content -->
                  <footer class="info_bar clearfix">
                    <ul class="unstyled list-inline row">
                      <li>
         <!-- AddToAny BEGIN -->
                        <a class="a2a_dd" href="https://www.addtoany.com/share"><img src="<?php echo base_url(); ?>assets/front/images/share.png" width="80" height="30" border="0" alt="Share"/></a>
                        <script async src="https://static.addtoany.com/menu/page.js"></script>
                        <!-- AddToAny END -->
                      </li> 
                      <li class="info_link col-sm-5 col-xs-6 col-lg-4">
                        <a style="padding:4px 5px;" href="details.php" class="btn btn-block btn-success btn-raised btn-sm">
                          View Deal
                        </a>
                      </li>
                    </ul>
                  </footer>
                </div>
              </div>
              <div class="col-sm-3">
                <div class="deal-entry green">
                 
                  <div class="image">
                    <a href="#" target="_blank" title="#">
                      <img src="<?php echo base_url(); ?>assets/front/images/affiliate-13.jpg" alt="#" class="img-responsive">
                    </a>
                    <span class="bought">
                      <i class="ti-tag">
                      </i>
                      79
                    </span>
                  </div>
                  <!-- /.image -->
                  <div class="title">
                    <a href="#" target="_blank" title="ATLETIKA 3 mēnešu abonements">
                      Product 2
                    </a>
                  </div>
                  <div class="entry-content">
                    <div class="prices clearfix">
                      
                      <div class="price">
                        <i class="ti-money">
                        </i>
                        
                        <b>
                          79,00
                        </b>
                      </div>
                      <div class="old-price">
                        <span>
                          <i class="ti-money">
                          </i>
                          171,00
                        </span>
                      </div>
                    </div>
                   
                  </div>
                  <!--/.entry content -->
                  <footer class="info_bar clearfix">
                    <ul class="unstyled list-inline row">
                      <li>
         <!-- AddToAny BEGIN -->
                        <a class="a2a_dd" href="https://www.addtoany.com/share"><img src="<?php echo base_url(); ?>assets/front/images/share.png" width="80" height="30" border="0" alt="Share"/></a>
                        <script async src="https://static.addtoany.com/menu/page.js"></script>
                        <!-- AddToAny END -->
                      </li> 
                      <li class="info_link col-sm-5 col-xs-6 col-lg-4">
                        <a style="padding:4px 5px;" href="details.php" class="btn btn-block btn-success btn-raised btn-sm">
                          View Deal
                        </a>
                      </li>
                    </ul>
                  </footer>
                </div>
              </div>
               <div class="col-sm-3">
                <div class="deal-entry  green">
                  
                  <div class="image">
                    <a href="#" target="_blank" title="#">
                      <img src="<?php echo base_url(); ?>assets/front/images/affiliate-12.jpg" alt="#" class="img-responsive">
                    </a>
                    <span class="bought">
                      <i class="ti-tag">
                      </i>
                      19
                    </span>
                  </div>
                  <!-- /.image -->
                  <div class="title">
                    <a href="#" target="_blank" title="ATLETIKA 3 mēnešu abonements">
                      Product 3
                    </a>
                  </div>
                  <div class="entry-content">
                    <div class="prices clearfix">
                      
                      <div class="price">
                        <i class="ti-money">
                        </i>
                        
                        <b>
                          78,00
                        </b>
                      </div>
                      <div class="old-price">
                        <span>
                          <i class="ti-money">
                          </i>
                          171,00
                        </span>
                      </div>
                    </div>
                   
                  </div>
                  <!--/.entry content -->
                  <footer class="info_bar clearfix">
                    <ul class="unstyled list-inline row">
                       <li>
         <!-- AddToAny BEGIN -->
                        <a class="a2a_dd" href="https://www.addtoany.com/share"><img src="<?php echo base_url(); ?>assets/front/images/share.png" width="80" height="30" border="0" alt="Share"/></a>
                        <script async src="https://static.addtoany.com/menu/page.js"></script>
                        <!-- AddToAny END -->
                      </li> 
                      <li class="info_link col-sm-5 col-xs-6 col-lg-4">
                        <a style="padding:4px 5px;" href="details.php" class="btn btn-block btn-success btn-raised btn-sm">
                          View Deal
                        </a>
                      </li>
                    </ul>
                  </footer>
                </div>
              </div>
               <div class="col-sm-3">
                <div class="deal-entry  green">
                 
                  <div class="image">
                    <a href="#" target="_blank" title="#">
                      <img src="<?php echo base_url(); ?>assets/front/images/affiliate-12.jpg" alt="#" class="img-responsive">
                    </a>
                    <span class="bought">
                      <i class="ti-tag">
                      </i>
                      19
                    </span>
                  </div>
                  <!-- /.image -->
                  <div class="title">
                    <a href="#" target="_blank" title="ATLETIKA 3 mēnešu abonements">
                     Product 4
                    </a>
                  </div>
                  <div class="entry-content">
                    <div class="prices clearfix">
                      
                      <div class="price">
                        <i class="ti-money">
                        </i>
                        
                        <b>
                          78,00
                        </b>
                      </div>
                      <div class="old-price">
                        <span>
                          <i class="ti-money">
                          </i>
                          171,00
                        </span>
                      </div>
                    </div>
                   
                  </div>
                  <!--/.entry content -->
                  <footer class="info_bar clearfix">
                    <ul class="unstyled list-inline row">
                      <li>
         <!-- AddToAny BEGIN -->
                        <a class="a2a_dd" href="https://www.addtoany.com/share"><img src="<?php echo base_url(); ?>assets/front/images/share.png" width="80" height="30" border="0" alt="Share"/></a>
                        <script async src="https://static.addtoany.com/menu/page.js"></script>
                        <!-- AddToAny END -->
                      </li> 
                      <li class="info_link col-sm-5 col-xs-6 col-lg-4">
                        <a style="padding:4px 5px;" href="details.php" class="btn btn-block btn-success btn-raised btn-sm">
                          View Deal
                        </a>
                      </li>
                    </ul>
                  </footer>
                </div>
              </div>
              <!--/.col -->
            </div>
            <!--/row -->
            
            <!--/.row -->
            <div class="row">
              <div class="col-sm-12 clearfix">
                <hr class="hr-grid-space" data-symbol="LAST MINUTE DEALS">
              </div>
            </div>
            <div class="row">
              <div class="col-sm-3">
                <div class="deal-entry  green">
                 
                  <div class="image">
                    <a href="#" target="_blank" title="#">
                      <img src="<?php echo base_url(); ?>assets/front/images/affiliate-12.jpg" alt="#" class="img-responsive">
                    </a>
                    <span class="bought">
                      <i class="ti-tag">
                      </i>
                      19
                    </span>
                  </div>
                  <!-- /.image -->
                  <div class="title">
                    <a href="#" target="_blank" title="ATLETIKA 3 mēnešu abonements">
                   Product 1
                    </a>
                  </div>
                  <div class="entry-content">
                    <div class="prices clearfix">
                      
                      <div class="price">
                        <i class="ti-money">
                        </i>
                        
                        <b>
                          78,00
                        </b>
                      </div>
                      <div class="old-price">
                        <span>
                          <i class="ti-money">
                          </i>
                          171,00
                        </span>
                      </div>
                    </div>
                    
                  </div>
                  <!--/.entry content -->
                  <footer class="info_bar clearfix">
                    <ul class="unstyled list-inline row">
                       <li>
         <!-- AddToAny BEGIN -->
                        <a class="a2a_dd" href="https://www.addtoany.com/share"><img src="<?php echo base_url(); ?>assets/front/images/share.png" width="80" height="30" border="0" alt="Share"/></a>
                        <script async src="https://static.addtoany.com/menu/page.js"></script>
                        <!-- AddToAny END -->
                      </li> 
                      <li class="info_link col-sm-5 col-xs-6 col-lg-4">
                        <a style="padding:4px 5px;" href="details.php" class="btn btn-block btn-success btn-raised btn-sm">
                          View Deal
                        </a>
                      </li>
                    </ul>
                  </footer>
                </div>
              </div>
              <div class="col-sm-3">
                <div class="deal-entry green">
                 
                  <div class="image">
                    <a href="#" target="_blank" title="#">
                      <img src="<?php echo base_url(); ?>assets/front/images/affiliate-13.jpg" alt="#" class="img-responsive">
                    </a>
                    <span class="bought">
                      <i class="ti-tag">
                      </i>
                      79
                    </span>
                  </div>
                  <!-- /.image -->
                  <div class="title">
                    <a href="#" target="_blank" title="ATLETIKA 3 mēnešu abonements">
                    Product 2
                    </a>
                  </div>
                  <div class="entry-content">
                    <div class="prices clearfix">
                     
                      <div class="price">
                        <i class="ti-money">
                        </i>
                        
                        <b>
                          79,00
                        </b>
                      </div>
                      <div class="old-price">
                        <span>
                          <i class="ti-money">
                          </i>
                          171,00
                        </span>
                      </div>
                    </div>
                    
                  </div>
                  <!--/.entry content -->
                  <footer class="info_bar clearfix">
                    <ul class="unstyled list-inline row">
                      <li>
         <!-- AddToAny BEGIN -->
                        <a class="a2a_dd" href="https://www.addtoany.com/share"><img src="<?php echo base_url(); ?>assets/front/images/share.png" width="80" height="30" border="0" alt="Share"/></a>
                        <script async src="https://static.addtoany.com/menu/page.js"></script>
                        <!-- AddToAny END -->
                      </li> 
                      <li class="info_link col-sm-5 col-xs-6 col-lg-4">
                        <a style="padding:4px 5px;" href="details.php" class="btn btn-block btn-success btn-raised btn-sm">
                          View Deal
                        </a>
                      </li>
                    </ul>
                  </footer>
                </div>
              </div>
               <div class="col-sm-3">
                <div class="deal-entry  green">
                  
                  <div class="image">
                    <a href="#" target="_blank" title="#">
                      <img src="<?php echo base_url(); ?>assets/front/images/affiliate-12.jpg" alt="#" class="img-responsive">
                    </a>
                    <span class="bought">
                      <i class="ti-tag">
                      </i>
                      19
                    </span>
                  </div>
                  <!-- /.image -->
                  <div class="title">
                    <a href="#" target="_blank" title="ATLETIKA 3 mēnešu abonements">
                      Product 3
                    </a>
                  </div>
                  <div class="entry-content">
                    <div class="prices clearfix">
                     
                      <div class="price">
                        <i class="ti-money">
                        </i>
                        
                        <b>
                          78,00
                        </b>
                      </div>
                      <div class="old-price">
                        <span>
                          <i class="ti-money">
                          </i>
                          171,00
                        </span>
                      </div>
                    </div>
                    
                  </div>
                  <!--/.entry content -->
                  <footer class="info_bar clearfix">
                    <ul class="unstyled list-inline row">
                     <li>
         <!-- AddToAny BEGIN -->
                        <a class="a2a_dd" href="https://www.addtoany.com/share"><img src="<?php echo base_url(); ?>assets/front/images/share.png" width="80" height="30" border="0" alt="Share"/></a>
                        <script async src="https://static.addtoany.com/menu/page.js"></script>
                        <!-- AddToAny END -->
                      </li> 
                      <li class="info_link col-sm-5 col-xs-6 col-lg-4">
                        <a style="padding:4px 5px;" href="details.php" class="btn btn-block btn-success btn-raised btn-sm">
                          View Deal
                        </a>
                      </li>
                    </ul>
                  </footer>
                </div>
              </div>
               <div class="col-sm-3">
                <div class="deal-entry  green">
                  <div class="offer-discount">
                    -81%
                  </div>
                  <div class="image">
                    <a href="#" target="_blank" title="#">
                      <img src="<?php echo base_url(); ?>assets/front/images/affiliate-12.jpg" alt="#" class="img-responsive">
                    </a>
                    <span class="bought">
                      <i class="ti-tag">
                      </i>
                      19
                    </span>
                  </div>
                  <!-- /.image -->
                  <div class="title">
                    <a href="#" target="_blank" title="ATLETIKA 3 mēnešu abonements">
                      Product 4
                    </a>
                  </div>
                  <div class="entry-content">
                    <div class="prices clearfix">
                      <div class="procent">
                        -81%
                      </div>
                      <div class="price">
                        <i class="ti-money">
                        </i>
                        
                        <b>
                          78,00
                        </b>
                      </div>
                      <div class="old-price">
                        <span>
                          <i class="ti-money">
                          </i>
                          171,00
                        </span>
                      </div>
                    </div>
                    
                  </div>
                  <!--/.entry content -->
                  <footer class="info_bar clearfix">
                    <ul class="unstyled list-inline row">
                      <li>
         <!-- AddToAny BEGIN -->
                        <a class="a2a_dd" href="https://www.addtoany.com/share"><img src="<?php echo base_url(); ?>assets/front/images/share.png" width="80" height="30" border="0" alt="Share"/></a>
                        <script async src="https://static.addtoany.com/menu/page.js"></script>
                        <!-- AddToAny END -->
                      </li> 
                      <li class="info_link col-sm-5 col-xs-6 col-lg-4">
                        <a style="padding:4px 5px;" href="details.php" class="btn btn-block btn-success btn-raised btn-sm">
                          View Deal
                        </a>
                      </li>
                    </ul>
                  </footer>
                </div>
              </div>
              <!--/.col -->
            </div>
            <div class="raw">
              <div class="view_more text-center">
                <button class="btn btn-warning "> View More</button>
              </div>
            </div>
            <!--/row -->
            
          </div>
         
          <!-- /main row -->
        </div>
      </section>
      <!-- /#page ends -->
 
      <!-- /.CTA -->
      <?php include('common/footer.php');?>
  </div>

  <!-- /animitsion -->
  <!-- JS files -->
  <script src="<?php echo base_url(); ?>assets/front/js/jquery.min.js">
  </script>
  <script src="<?php echo base_url(); ?>assets/front/js/kupon.js">
  </script>
  <script src="<?php echo base_url(); ?>assets/front/js/bootstrap.min.js">
  </script>
  <script src="<?php echo base_url(); ?>assets/front/js/jquery.animsition.min.js">
  </script>
  <script src="<?php echo base_url(); ?>assets/front/owl.carousel/owl.carousel.js">
  </script>
  <script src="<?php echo base_url(); ?>assets/front/js/jquery.flexslider-min.js">
  </script>
  <script src="<?php echo base_url(); ?>assets/front/js/plugins.js">
  </script>


  </body>
  

<!-- Mirrored from codenpixel.com/demo/kupon/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 09 Dec 2015 06:58:25 GMT -->
</html>