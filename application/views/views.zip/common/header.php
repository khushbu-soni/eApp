<header>

  <!-- Piwik -->
<script type="text/javascript">
  var _paq = _paq || [];
  _paq.push(["setDomains", ["*.localhost/bargain"]]);
  _paq.push(['trackPageView']);
  _paq.push(['enableLinkTracking']);
  (function() {
    var u="//localhost/piwiky/";
    _paq.push(['setTrackerUrl', u+'piwik.php']);
    _paq.push(['setSiteId', 1]);
    var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
    g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'piwik.js'; s.parentNode.insertBefore(g,s);
  })();
</script>
<noscript><p><img src="//localhost/piwiky/piwik.php?idsite=1" style="border:0;" alt="" /></p></noscript>
<!-- End Piwik Code -->


        <div class="top-bar bg-light hdden-xs">
          <div class="container">
            <div class="row">
              <div class="col-sm-6 list-inline list-unstyled no-margin hidden-xs">
                <p class="no-margin">
                  Have any questions?
                  <strong>
                    +080 124 880
                              </strong>
                              or mail@xyz.com
                          </p>
                      </div>
                      <div class="pull-right col-sm-6">
                        <ul class="list-inline list-unstyled pull-right">
                          <li class="active">
                            <a href="contact.php">
                              <i class="ti-cart">
                              </i>
                              Contact us
                            </a>
                          </li>
                          <li class="active">
                            <a href="faq.php">
                              <i class="ti-cart">
                              </i>
                              Faq
                            </a>
                          </li>
                          <li>
                            <a href="log_in.php">
                              Sign In
                            </a>
                          </li>
                          <li>
                            <a href="registration.php">
                              Sign Up
                            </a>
                          </li>
                          <li>
                            <a href="cart.php">
                              <i class="ti-shopping-cart">
                              </i>
                              Cart
                            </a>
                          </li>
                        </ul>
                      </div>
                  </div>
              </div>
          </div>
          <div id="nav-wrap">
            <div class="nav-wrap-holder">
              <div class="container" id="nav_wrapper">
                <nav class="navbar navbar-static-top nav-white" id="main_navbar" role="navigation">
                  <!-- Brand and toggle get grouped for better mobile display -->
                  <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#Navbar">
                      <span class="sr-only">
                        Toggle navigation
                                  </span>
                                  <span class="icon-bar">
                                  </span>
                                  <span class="icon-bar">
                                  </span>
                                  <span class="icon-bar">
                                  </span>
                              </button>
                              <a href="index.php" class="navbar-brand logo col-sm-3">
                                <img src="images/dummy_logo.png" alt="" class="img-responsive">
                              </a>
                          </div>
                          <!-- Collect the nav links, forms, and other content for toggling -->
                          <div class="collapse navbar-collapse" id="Navbar">
                            <!-- regular link -->
                            <ul class="nav navbar-nav navbar-right">
                             <li>
                                <a href="results.php">
                                  Category 1st
                                </a>
                              </li>
                              <li>
                                <a href="results.php">
                                  Category 2nd
                                </a>
                              </li>
                              <li>
                                <a href="results.php">
                                  Category 3rd
                                </a>
                              </li>
                              <li>
                                <a href="results.php">
                                  Category 4th
                                </a>
                              </li>
                              <li>
                                <a href="results.php">
                                  Category 5th
                                </a>
                              </li>
                              <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                  
                                  </i>
                                  Hello Jhon
                                  <span class="caret">
                                  </span>
                                </a>
                                <ul class="dropdown-menu" role="menu">
                                  <li>
                                    <a href="user_edit.php">
                                     Edit Profile
                                    </a>
                                  </li>
                                  <li>
                                    <a href="user_edit.php">
                                     Log Out
                                    </a>
                                  </li>
                                  
                                </ul>
                              </li>
                            </ul>
                          </div>
                      </nav>
                  </div>
              </div>
              <!-- /.div nav wrap holder -->
          </div>
          <!-- /#nav wrap -->
      </header>