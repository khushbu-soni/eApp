<footer id="footer">
        <div class="container">
          <div class="col-sm-4">
            <img src="images/dummy_logo.png" alt="#" class="img-responsive logo">
            <p>
              Kupon,travel deals &amp; publishing,with minimal design. We provide you with the latest fresh inspiration straight from the industrie.
            </p>
          </div>
          <div class="col-sm-4">
            <h5>
              COMMON TAGS
            </h5>
            <ul class="tags">
              <li>
                <a href="#" class="tag">
                  Vacation
                </a>
              </li>
              <li>
                <a href="#" class="tag">
                  Rentals
                </a>
              </li>
              <li>
                <a href="#" class="tag">
                  Deals
                </a>
              </li>
              <li>
                <a href="#" class="tag">
                  Travel deals
                </a>
              </li>
              <li>
                <a href="#" class="tag">
                  Vacation deals
                </a>
              </li>
              <li>
                <a href="#" class="tag">
                  Adriatic coast
                </a>
              </li>
              <li>
                <a href="#" class="tag">
                  Europe
                </a>
              </li>
              <li>
                <a href="#" class="tag">
                  Island
                </a>
              </li>
            </ul>
          </div>
          <div class="col-sm-2">
            <h5>
              CATEGORIES
            </h5>
            <ul class="list-unstyled">
              <li>
                Vacation Deals
              </li>
              <li>
                Online Deals
              </li>
              <li>
                Digital goods
              </li>
              <li>
                Travel Deals
              </li>
              <li>
                Hotel deals
              </li>
              <li>
                Featured
              </li>
              <li>
                All Categories ..
              </li>
            </ul>
          </div>
          <div class="col-sm-2">
            <h5>
              ABOUT US
            </h5>
            <ul class="list-unstyled">
              <li>
                Available Jobs
              </li>
              <li>
                Sumbit Deal
              </li>
              <li>
                Contact Us
              </li>
              <li>
                History
              </li>
              <li>
                Impressium
              </li>
            </ul>
          </div>
        </div>
        <div class="btmFooter">
          <div class="container">
            <div class="col-sm-7">
              <p>
                <strong>
                  Copyright 2015 
                </strong>
                 deals and Coupons template made with
                <i class="ti-heart">
                </i>
                <strong>
                  by Hogo Works Solutions
                </strong>
              </p>
            </div>
            <div class="col-sm-5">
              <ul class="pay-opt pull-right list-inline list-unstyled">
                <li>
                  <a href="#" title="#">
                    <img src="images/amz-icon.png" class="img-responsive" alt="">
                  </a>
                </li>
                <li>
                  <a href="#" title="#">
                    <img src="images/paypal-icon.png" class="img-responsive" alt="">
                  </a>
                </li>
                <li>
                  <a href="#" title="#">
                    <img src="images/ax-icon.png" class="img-responsive" alt="">
                  </a>
                </li>
                <li>
                  <a href="#" title="#">
                    <img src="images/mb-icon.png" class="img-responsive" alt="">
                  </a>
                </li>
                <li>
                  <a href="#" title="#">
                    <img src="images/mst-icon.png" class="img-responsive" alt="">
                  </a>
                </li>
                <li>
                  <a href="#" title="#">
                    <img src="images/mstr-icon.png" class="img-responsive" alt="">
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </footer>