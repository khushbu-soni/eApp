 <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600' rel='stylesheet' type='text/css'>
<link href="<?php echo base_url('assets/plugins/pace-master/themes/blue/pace-theme-flash.css') ;?>" rel="stylesheet"/>
<link href="<?php echo base_url('assets/plugins/uniform/css/uniform.default.min.css') ;?>" rel="stylesheet"/>
<link href="<?php echo base_url('assets/plugins/bootstrap/css/bootstrap.min.css') ;?>" rel="stylesheet"/>
<link href="<?php echo base_url('assets/plugins/fontawesome/css/font-awesome.css') ;?>" rel="stylesheet"/>
<link href="<?php echo base_url('assets/plugins/line-icons/simple-line-icons.css') ;?>" rel="stylesheet"/>
<link href="<?php echo base_url('assets/plugins/offcanvasmenueffects/css/menu_cornerbox.css') ;?>" rel="stylesheet"/>
<link href="<?php echo base_url('assets/plugins/waves/waves.min.css') ;?>" rel="stylesheet"/>
<link href="<?php echo base_url('assets/plugins/waves/waves.min.css') ;?>" rel="stylesheet"/>
<link href="<?php echo base_url('assets/plugins/switchery/switchery.min.css') ;?>" rel="stylesheet"/>
<link href="<?php echo base_url('assets/css/modern.min.css') ;?>" rel="stylesheet"/>
<link href="<?php echo base_url('assets/css/themes/green.css') ;?>" rel="stylesheet"/>
<link href="<?php echo base_url('assets/css/themes/green.css') ;?>" rel="stylesheet"/>
<link href="<?php echo base_url('assets/css/custom.css') ;?>" rel="stylesheet"/>
<link href="<?php echo base_url('assets/plugins/3d-bold-navigation/js/modernizr.js') ;?>" rel="stylesheet"/>
<link href="<?php echo base_url('assets/plugins/offcanvasmenueffects/js/snap.svg-min.js') ;?>" rel="stylesheet"/>


<!-- Theme Styles -->

