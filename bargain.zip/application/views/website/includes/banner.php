<!--Banner-->
<section id="banner2">
  <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
     <!-- Wrapper for slides -->
     <div class="carousel-inner">
          <!--item-1-->
        <div class="item active">
              <img src="<?php echo base_url(); ?>website/images/img1.jpg" alt="image">
              <div class="carousel-caption">
                <div class="banner_text text-center div_zindex white-text">
                        <h2>Buy Your New Battery Or Used Battery. </h2>
                        <h3>We have more than a thousand batteries for you to choose. </h3>
                        <a href="#" class="btn">Read More</a>
                    </div>
              </div>
          </div>
        
          <!--item-2-->
        <div class="item">
              <img src="<?php echo base_url(); ?>website/images/ig2.jpg" alt="image">
              <div class="carousel-caption">
                <div class="banner_text text-center div_zindex white-text">
                        <h2>Find Your Solutions Here.</h2>
                        <h3>We have more than a thousand batteries for you to choose. </h3>
                        <a href="#" class="btn">Read More</a>
                    </div>
              </div>
          </div>
     </div>

          <!-- Controls -->
          <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
            <div class="icon-prev"></div>
          </a>
          <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
            <div class="icon-next"></div>
          </a>
    </div>
</section>
<!--/Banner-->
