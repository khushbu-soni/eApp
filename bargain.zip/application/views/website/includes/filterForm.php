<section id="filter_form2">
  <div class="container">
    <div class="main_bg white-text">
        <h3>Find Your Battery</h3>
        <div class="row">
          <form action="#" method="get">
            <div class="form-group col-md-3 col-sm-6">
              <div class="selectw">
                <input type="text"  id="default" list="model_list" placeholder="Choose Make" style="color:black" value="" autocomplete='off' >
                
                <datalist id="model_list">
                  
                </datalist>
              </div>
            </div>
            <!-- <div class="form-group col-md-3 col-sm-6"> -->
              <!-- <div class="select">
                <select class="form-control">
                  <option>Select Brand</option>
                  <option>Brand 1</option>
                  <option>Brand 2</option>
                  <option>Brand 3</option>
                  <option>Brand 4</option>
                </select>
              </div>
            </div> -->
            <div class="form-group col-md-3 col-sm-6">
              <div class="selectw">
                <input type="text" id="ajax" list="json-datalist" placeholder="choose Model" style="color:black" value="" autocomplete='off' >
                <datalist id="json-datalist"></datalist>
              </div>
            </div>
            <!-- <div class="form-group col-md-3 col-sm-6">
              <div class="select">
                <select class="form-control">
                  <option>Year of Model </option>
                  <option>2016</option>
                  <option>2015</option>
                  <option>2014</option>
                </select>
              </div>
            </div> -->
            
            <!-- <div class="form-group col-md-6 col-sm-6">
              <label class="form-label">Price Range ($) </label>
              <input id="price_range" type="text" class="span2" value="" data-slider-min="50" data-slider-max="6000" data-slider-step="5" data-slider-value="[1000,5000]"/>
            </div> -->
            
            
            <div class="form-group col-md-3 col-sm-6">
              <button type="submit" class="btn btn-block"><i class="fa fa-search" aria-hidden="true"></i> Search </button>
            </div>
            <div class="form-group col-md-3 col-sm-6">
             <h4>
             Have a question ? Call Now: <p>✆ 7588-010101 / 7588-020202</p>
             </h4>

            </div>
          </form>
        </div>
    </div>
  </div>
</section>