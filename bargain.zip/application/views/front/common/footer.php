<footer id="footer">
        <div class="container">
          <div class="col-sm-4">
            <img src="<?php echo base_url(); ?>assets/front/images/dummy_logo1.png" alt="#" class="img-responsive logo">
            <h4>We Are Also On Google Play & IOS</h4>
            <img src="<?php echo base_url(); ?>assets/front/images/iphone.png" class="img-responsive col-md-4 col-xs-6">
            <img src="<?php echo base_url(); ?>assets/front/images/android.png" class="img-responsive col-md-4 col-xs-6">
          </div>
          <div class="col-sm-4">
            <h5>
              COMMON TAGS
            </h5>
            <ul class="tags">
              <li>
                <a href="#" class="tag">
                  Vacation
                </a>
              </li>
              <li>
                <a href="#" class="tag">
                  Rentals
                </a>
              </li>
              <li>
                <a href="#" class="tag">
                  Deals
                </a>
              </li>
              <li>
                <a href="#" class="tag">
                  Travel deals
                </a>
              </li>
              <li>
                <a href="#" class="tag">
                  Vacation deals
                </a>
              </li>
              <li>
                <a href="#" class="tag">
                  Adriatic coast
                </a>
              </li>
              <li>
                <a href="#" class="tag">
                  Europe
                </a>
              </li>
              <li>
                <a href="#" class="tag">
                  Island
                </a>
              </li>
            </ul>
          </div>
          <div class="col-sm-2">
            <h5>
              CATEGORIES
            </h5>
            <ul class="list-unstyled">
              <li>
               <a href=""> Vacation Deals</a></a>
              </li>
              <li>
                <a href=""> Online Deals</a>
              </li>
              <li>
                <a href=""> Digital goods</a>
              </li>
              <li>
                 <a href="">Travel Deals</a>
              </li>
              <li>
                 <a href="">Hotel deals</a>
              </li>
              <li>
                <a href=""> Featured</a>
              </li>
              <li>
                <a href=""> All Categories ..</a>
              </li>
            </ul>
          </div>
          <div class="col-sm-2">
            <h5>
               <a href="">ABOUT US</a>
            </h5>
            <ul class="list-unstyled">
              <li>
                <a href=""> Available Jobs</a>
              </li>
              <li>
                <a href=""> Sumbit Deal</a>
              </li>
              <li>
                <a href=""> Contact Us</a>
              </li>
              <li>
                <a href=""> History</a>
              </li>
              <li>
                 <a href="">Impressium</a>
              </li>
            </ul>
          </div>
        </div>
        <div class="btmFooter">
          <div class="container">
            <div class="col-sm-7">
              <p>
                <strong>
                  Copyright 2015 
                </strong>
                 deals and Coupons template made with
                <i class="ti-heart">
                </i>
                <strong>
                  by Hogo Works Solutions
                </strong>
              </p>
            </div>
            <div class="col-sm-5">
              <ul class="pay-opt pull-right list-inline list-unstyled">
                <li>
                  <a href="#" title="#">
                    <img src="<?php echo base_url(); ?>assets/front/images/amz-icon.png" class="img-responsive" alt="">
                  </a>
                </li>
                <li>
                  <a href="#" title="#">
                    <img src="<?php echo base_url(); ?>assets/front/images/paypal-icon.png" class="img-responsive" alt="">
                  </a>
                </li>
                <li>
                  <a href="#" title="#">
                    <img src="<?php echo base_url(); ?>assets/front/images/ax-icon.png" class="img-responsive" alt="">
                  </a>
                </li>
                <li>
                  <a href="#" title="#">
                    <img src="<?php echo base_url(); ?>assets/front/images/mb-icon.png" class="img-responsive" alt="">
                  </a>
                </li>
                <li>
                  <a href="#" title="#">
                    <img src="<?php echo base_url(); ?>assets/front/images/mst-icon.png" class="img-responsive" alt="">
                  </a>
                </li>
                <li>
                  <a href="#" title="#">
                    <img src="<?php echo base_url(); ?>assets/front/images/mstr-icon.png" class="img-responsive" alt="">
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </footer>