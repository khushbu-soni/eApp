<ul class="sidebar-menu" id="nav-accordion">
              
              	  <p class="centered"><a href="profile.html"><img src="<?php echo base_url(); ?>assets/img/ui-sam.jpg" class="img-circle" width="60"></a></p>
              	  <h5 class="centered">Marcel Newman</h5>
              	  	
                  <li class="mt">
                      <a class="active" href="index.html">
                          <i class="fa fa-dashboard"></i>
                          <span>Dashboard</span>
                      </a>
                  </li>

                  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-desktop"></i>
                          <span>Orders</span>
                      </a>
                      <ul class="sub">
                          <li><a  href="">Orders</a></li>
                          <li><a  href="">Drafts</a></li>
                          <li><a  href="">Abandoned checkouts</a></li>
                      </ul>
                  </li>

                  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-cogs"></i>
                          <span>Products</span>
                      </a>
                      <ul class="sub">
                          <li><a  href="<?php echo base_url(); ?>merchant/merchant/products">Products</a></li>
                          <li><a  href="">Transfers</a></li>
                          <li><a  href="">Inventory</a></li>
                          <li><a  href="">Collections</a></li>
                          <li><a  href="">Gift cards</a></li>
                      </ul>
                  </li>
                  <li class="sub-menu">
                      <a href="" >
                          <i class="fa fa-users"></i>
                          <span>Customers</span>
                      </a>
                  </li>
                  <li class="sub-menu">
                      <a href="" >
                          <i class="fa fa-tasks"></i>
                          <span>Reports</span>
                      </a>
                  </li>
                  <li class="sub-menu">
                      <a href="" >
                          <i class="fa fa-th"></i>
                          <span>Discounts</span>
                      </a>
                  </li>
              </ul>