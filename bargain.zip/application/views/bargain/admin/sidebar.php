<div class="left-side-inner">

				<!--sidebar nav start-->
					<ul class="nav nav-pills nav-stacked custom-nav">
						<li class="active" id='dashboard'><a href="index.html"><i class="lnr lnr-power-switch"></i><span>Dashboard</span></a></li>
						<li class="menu-list" id='category'>
							<a href="#"><i class="lnr lnr-cog"></i>
								<span>Masters</span></a>
								<ul class="sub-menu-list">
									<li><a href="<?php echo base_url();?>admin/state">State</a> </li>
<!-- 									<li><a href="<?php echo base_url();?>admin/category">Main Categories</a> </li> -->
									<li><a href="<?php echo base_url();?>admin/city">City</a> </li>
									<li><a href="<?php echo base_url();?>admin/productType">Product Type</a> </li>
									<li><a href="<?php echo base_url();?>admin/make">Make</a> </li>
									<li><a href="<?php echo base_url();?>admin/model">Model</a> </li><!-- 
									<li><a href="<?php echo base_url();?>admin/merchant">Marchants</a> </li> -->
									<li><a href="<?php echo base_url();?>admin/fuelType">Fuel Type</a> </li>
									<li><a href="<?php echo base_url();?>admin/locations">Battery Brand</a> </li>
									<li><a href="<?php echo base_url();?>admin/dataList">Manage Products</a> </li>
									<li><a href="<?php echo base_url();?>import">Import</a> </li>
								</ul>
						</li>
						<li class="menu-list" id='category'>
							<a href="#"><i class="lnr lnr-spell-check"></i>
								<span>Not Active</span></a>
								<ul class="sub-menu-list">
									<!-- <li><a href="<?php echo base_url();?>admin/deal/type">Deal Types</a> </li>
									<li><a href="<?php echo base_url();?>admin/deal">Manage Deals</a> </li>
									<li><a href="<?php echo base_url();?>admin/locations">Manage Offers</a> </li>
									<li><a href="<?php echo base_url();?>admin/locations">Trash</a> </li> -->
								</ul>
						</li>
						<li class="menu-list" id='category'>
							<a href="#"><i class="lnr lnr-spell-check"></i>
								<span>Not Active</span></a>
								<ul class="sub-menu-list">
									<!-- <li><a href="<?php echo base_url();?>admin/order">Orders</a> </li>
									<li><a href="<?php echo base_url();?>admin/order/delivery">Invoices & Delivery</a> </li>
									<li><a href="<?php echo base_url();?>admin/order/salesadjustment">Sales Adjustment</a> </li>
									<li><a href="<?php echo base_url();?>admin/locations">Trash</a> </li>
									 --><!-- <li><a href="<?php //echo base_url();?>admin/subscribe">Credit Memos</a> </li> -->
								</ul>
						</li>
						

						<li class="menu-list" id='customers'>
							<a href="#"><i class="lnr lnr-user"></i>
								<span>Not Active</span></a>
								<ul class="sub-menu-list">
									<!-- <li><a href="<?php echo base_url();?>admin/customer">Manage Customers</a> </li>
									<li><a href="<?php echo base_url();?>admin/customer/group">Customer Groups</a> </li>
									<li><a href="<?php echo base_url();?>admin/locations">Online Customers</a> </li>
									<li><a href="<?php echo base_url();?>admin/locations">Trash</a> </li>
									<li><a href="<?php echo base_url();?>s/dataList">Manage Products</a> </li> -->
								</ul>
						</li>
						<li class="menu-list"><a href="#"><i class="lnr lnr-cog"></i> <span>Manage Products</span></a>
						</li>           
						<li class="menu-list"><a href="<?php echo base_url();?>list"><i class="lnr lnr-cog"></i> <span>Manage Products</span></a>
							<ul class="sub-menu-list">
								<li><a href="<?php echo base_url();?>import">Import</a> </li>
								<!-- <li><a href="compose-mail.html">Compose Mail</a></li> -->
							</ul>
						</li>      
						<li class="menu-list"><a href="#"><i class="lnr lnr-indent-increase"></i> <span>Menu Levels</span></a>  
							<ul class="sub-menu-list">
								<li><a href="charts.html">Basic Charts</a> </li>
							</ul>
						</li>
						<li><a href="codes.html"><i class="lnr lnr-pencil"></i> <span>Typography</span></a></li>
						<li><a href="media.html"><i class="lnr lnr-select"></i> <span>Media Css</span></a></li>
						<li class="menu-list"><a href="#"><i class="lnr lnr-book"></i>  <span>Pages</span></a> 
							<ul class="sub-menu-list">
								<li><a href="sign-in.html">Sign In</a> </li>
								<li><a href="sign-up.html">Sign Up</a></li>
								<li><a href="blank_page.html">Blank Page</a></li>
							</ul>
						</li>
					</ul>
				<!--sidebar nav end-->
			</div>