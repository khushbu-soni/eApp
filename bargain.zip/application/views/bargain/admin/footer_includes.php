 
   <script src="<?php echo base_url();?>assets/bargain/admin/js/bootstrap.min.js"></script>
<script src="<?php echo base_url();?>assets/bargain/admin/js/jquery.nicescroll.js"></script>
<script src="<?php echo base_url();?>assets/bargain/admin/js/scripts.js"></script>
<!-- Bootstrap Core JavaScript -->
   <script type="text/javascript">
  $(document).ready(function() {
   $('#example').DataTable( {
        "pagingType": "full_numbers"
    } );
} );
   </script>