<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['appID']	= '1667752626812278';


$config['appSecret']	= '5e5dc589c8e0adebe8518d2d4cd213a7';


/* End of file facebook.php */
/* Location: ./application/config/facebook.php */
