<?php

defined('BASEPATH') OR exit('No direct script access allowed');

$config['googleplus']['application_name'] = 'myendorse';
$config['googleplus']['client_id']        = '768511394602-bpes48arotgcjso4c01q8oog0t4mloqs.apps.googleusercontent.com';
$config['googleplus']['client_secret']    = 'qpS3n9tbYViy24Yeko15WHmt';
$config['googleplus']['redirect_uri']     = 'http://localhost/test';
// $config['googleplus']['home_uri']          = 'http://www.myendorse.com/welcome';
$config['googleplus']['scopes']           = array();

