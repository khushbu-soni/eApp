<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
    $config['google']['application_name'] = '';
    $config['google']['client_id'] = '768511394602-bpes48arotgcjso4c01q8oog0t4mloqs.apps.googleusercontent.com';
    $config['google']['client_secret'] = 'qpS3n9tbYViy24Yeko15WHmt';
    $config['google']['redirect_uri'] = 'http://www.myendorse.com';
    $config['google']['api_key'] =’’; 